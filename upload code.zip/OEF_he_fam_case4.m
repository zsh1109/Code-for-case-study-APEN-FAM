clc,clear
%% OEF����
sumcost=0;%�ܷ���
len=72;
mpc=case118;

%% ��������
Pd=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','electric load');%�縺�ɱ���
Pd=Pd(:,1:2:143);%�й�����
%������ɱ�����������
loc_chp=[54;61;103;49;25;111;12];
Y=full(makeYbus(mpc));
G=real(Y);
B=imag(Y);
N_bus=size(mpc.bus,1);
N_gen=size(mpc.gen,1);
N_branch=size(mpc.branch,1);
cof=zeros(118,1);
for j=1:N_bus
    if mpc.bus(j,3)~=0
        cof=mpc.bus(j,4)/mpc.bus(j,3);
    end
end
Qd=Pd.*cof;%�����޹�
flag_con1={};%��ڵ�������֧·��
flag_con2={};
for j=1:N_bus
    loc1=find(mpc.branch(:,1)==j);
    loc2=find(mpc.branch(:,2)==j);
    flag_con1{j}=sort(loc1);
    flag_con2{j}=sort(loc2);
end
%����֧·������
set_hv=find(mpc.bus(:,10)==345);
Smax=zeros(N_branch,1);
for j=1:N_branch
    if ismember(mpc.branch(j,1),set_hv)==1 | ismember(mpc.branch(j,2),set_hv)==1
        Smax(j)=1000;
    else
        Smax(j)=200;
    end
end
loc_pq=find(mpc.bus(:,2)==1);
loc_sr=find(mpc.bus(:,2)~=1);
loc_gt1=mpc.gen(:,1);
loc_gt1([22;26;46;21;11;51;6])=[];%��ͨ��������
loc_gt2=(1:N_gen)';
loc_gt2([22;26;46;21;11;51;6])=[];%��ͨ��������
%�ڵ㹦�ʡ���ѹ��Ϣ
Pg=sdpvar(N_bus,len);
Qg=sdpvar(N_bus,len);
Vm=sdpvar(N_bus,len);
Va=sdpvar(N_bus,len);
Pl=sdpvar(N_branch,len);
Ql=sdpvar(N_branch,len);

cons=[Va(69,:)==zeros(1,len)];
for j=1:len
    cons=cons+[Pg(loc_pq,j)==zeros(length(loc_pq),1);
        Qg(loc_pq,j)==zeros(length(loc_pq),1);%���ɽڵ��й��޹�
        mpc.gen(:,5)<=Qg(loc_sr,j)<=mpc.gen(:,4);
        mpc.gen(loc_gt2,10)<=Pg(loc_gt1,j)<=mpc.gen(loc_gt2,9);%���������������
        mpc.bus(:,13)<=Vm(:,j)<=mpc.bus(:,12);%��ѹ������
        -pi/2*ones(N_bus,1)<=Va(:,j)<=pi/2*ones(N_bus,1);
        Pl(:,j).^2+Ql(:,j).^2<=Smax.^2;
        ];
end
for j=1:N_branch%֧·����
    f=mpc.branch(j,1);%��ĩ�ڵ�
    t=mpc.branch(j,2);
    for k=1:len
        cons=cons+[
        Pl(j,k)==-(G(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-B(f,t)*(Va(f,k)-Va(t,k))+1/2*G(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100;
        Ql(j,k)==-(-B(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-G(f,t)*(Va(f,k)-Va(t,k))-1/2*B(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100];
    end
end

for j=1:N_bus
    loc1=flag_con1{j};
    loc2=flag_con2{j};
    for k=1:len
        cons=cons+[
        Pg(j,k)==Pd(j,k)+sum(Pl(loc1,k))-sum(Pl(loc2,k))+sum(G(j,:))*Vm(j,k)^2*100;
        Qg(j,k)==Qd(j,k)+sum(Ql(loc1,k))-sum(Ql(loc2,k))-sum(B(j,:))*Vm(j,k)^2*100];
    end
end

%% ��������
node1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node5');%DHN1,51�ڵ�
pipe1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe5');
node2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node4');%DHN3,198�ڵ�
pipe2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe4');
data=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','Heat load3');
tao=20*60;data=data(1:2:143,:);
Tload=data(:,1);Tsmin=data(:,2);Trmin=data(:,4);
Tsmax=data(:,3);Trmax=data(:,5);
inits=100;initr=60;

%51�ڵ�
l1=pipe1(:,4);lamda1=pipe1(:,6);m1=pipe1(:,8);Qmax1=60;
v1=pipe1(:,9);d1=node1(:,6);Dy1=l1./v1;
[n_sr1,n_ns1,n_nl1,n_ld1,n_sl1,n_nd1,n_br1]=reldata1(node1,pipe1);
%199�ڵ�
l2=pipe2(:,4);lamda2=pipe2(:,6);m2=pipe2(:,8);Qmax2=220;
v2=pipe2(:,9);d2=node2(:,6);Dy2=l2./v2;
[n_sr2,n_ns2,n_nl2,n_ld2,n_sl2,n_nd2,n_br2]=reldata1(node2,pipe2);

%% ·��-DHN1
for num_hn=1:2
    eval(['node=node',num2str(num_hn),';']);eval(['pipe=pipe',num2str(num_hn),';']);
    eval(['l=l',num2str(num_hn),';']);eval(['lamda=lamda',num2str(num_hn),';']);
    eval(['m=m',num2str(num_hn),';']);eval(['v=v',num2str(num_hn),';']);eval(['d=d',num2str(num_hn),';']);
    eval(['Dy=Dy',num2str(num_hn),';']);
    
    [n_sr,n_ns,n_nl,n_ld,n_sl,n_nd,n_br]=reldata1(node,pipe);
    Pmatrix=zeros(n_nd);
    for j=1:n_br
        Pmatrix(pipe(j,2),pipe(j,3))=Dy(j);
    end 
    Pb=cell(length(n_sr),length(n_ld));
    for i=1:length(n_sr)
        for j=1:length(n_ld)
            Pb{i,j}=findPath(Pmatrix,n_sr(i),n_ld(j),0);
        end   
    end
    Sloss=zeros(n_br,1);Tloss=zeros(n_br,1);
    for j=1:n_br
        Sloss(j)=exp(-l(j)/4182/m(j)/lamda(j));
        Tloss(j)=-v(j)/4182/m(j)/lamda(j);
    end
    Paths=cell(length(n_sr),length(n_ld));
    Pathr=cell(length(n_ld),length(n_sr));
    for i=1:length(n_sr)
        for k=1:length(n_ld)
            tempPb=Pb{i,k};
            Path=[];
            if sum(tempPb)~=0
                for num=1:n_nd
                    tempp=find(pipe(:,2)==tempPb(num) & pipe(:,3)==tempPb(num+1));
                    Path=[Path;tempp];
                end
            end
            Paths{i,k}=flip(Path);
            Pathr{k,i}=Path;
        end
    end
    Ms=zeros(length(n_sr),length(n_ld));
    for i=1:length(n_sr)
        for j=1:length(n_ld)
            temp=Paths{i,j};
            if isempty(temp)~=0
                Ms(i,j)=0;
            else
                tempMs=zeros(length(temp),1);
                for k=1:length(tempMs)
                    if ismember(pipe(temp(k),3),n_ld)==1
                        tempMs(k)=m(temp(k))/d(pipe(temp(k),3));
                    else
                        fpipe=find(pipe(:,2)==pipe(temp(k),3));
                        tempMs(k)=m(temp(k))/sum(m(fpipe));
                    end
                end
                Ms(i,j)=prod(tempMs);
            end
        end
    end
    Mr=zeros(length(n_ld),length(n_sr));
    for i=1:length(n_ld)
        for j=1:length(n_sr)
            temp=Pathr{i,j};
            if isempty(temp)~=0
                Mr(i,j)=0;
            else
                tempMr=zeros(length(temp),1);
                for k=1:length(tempMr)
                    fpipe=find(pipe(:,3)==pipe(temp(k),2));
                    tempMr(k)=m(temp(k))/(sum(m(fpipe))-d(pipe(temp(k),2)));
                end
                Mr(i,j)=prod(tempMr);
            end
        end
    end
    clear Pb Pmatrix
    eval(['Tloss',num2str(num_hn),'=Tloss;']);eval(['Sloss',num2str(num_hn),'=Sloss;']);
    eval(['Paths',num2str(num_hn),'=Paths;']);eval(['Pathr',num2str(num_hn),'=Pathr;']);
    eval(['Ms',num2str(num_hn),'=Ms;']);eval(['Mr',num2str(num_hn),'=Mr;']);
end

%% ��Լ��
%DHN1
Qchp1=sdpvar(len,1);
Tssr1=sdpvar(len,1);
Trsr1=sdpvar(len,1);
Trsr_com1=sdpvar(len,length(n_ld1));
Tsld1=sdpvar(len,length(n_ld1));
Trld1=sdpvar(len,length(n_ld1));
for j=1:len
    sumcost=sumcost+0.04*Qchp1(j)^2+20*Qchp1(j);
    cons=cons+[Qchp1(j)==-d1(1)*4.182*10^-3*(Tssr1(j)-Trsr1(j))];
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp1(j)-Qchp1(j-1)<=Qmax1*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr1<=Tsmax];
cons=cons+[Trmin<=Trsr1<=Trmax];
for i=1:length(n_ld1)
    cons=cons+[Tsmin<=Tsld1(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld1(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld1)
        Path=Paths1{i};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Tsld1(j,i)==inits*exp(Tloss1(Path(1))*j*tao)*Ms1(i)];
            elseif j*tao>Dy1(Path(1)) && j*tao<=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:(num+1))))
                        cons=cons+[Tsld1(j,i)==inits*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Ms1(i)];
                    end
                end
            else
                cons=cons+[Tsld1(j,i)==Tssr1(ceil((j*tao-sum(Dy1(Path)))/tao))*prod(Sloss1(Path))*Ms1(i)];
            end
        end
    end
    for i=1:length(n_ld1)
        cons=cons+[Trld1(j,i)==Tsld1(j,i)-(Tload(j)/4.182*1000./d1(n_ld1(i)))];
    end
    for k=1:length(n_ld1)
        Path=Pathr1{k};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Trsr_com1(j,k)==initr*exp(Tloss1(Path(1))*j*tao)*Mr1(k)];
            elseif j*tao>Dy1(Path(1)) && j*tao <=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:num+1)))
                        cons=cons+[Trsr_com1(j,k)==initr*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Mr1(k)];
                    end
                end
            else
                cons=cons+[Trsr_com1(j,k)==Trld1(ceil((j*tao-sum(Dy1(Path)))/tao),k)*prod(Sloss1(Path))*Mr1(k)];
            end
        end
    end
    cons=cons+[Trsr1(j)==sum(Trsr_com1(j,:))];
end 

%DHN2
Qchp2=sdpvar(len,1);
Tssr2=sdpvar(len,1);
Trsr2=sdpvar(len,1);
Trsr_com2=sdpvar(len,length(n_ld2));
Tsld2=sdpvar(len,length(n_ld2));
Trld2=sdpvar(len,length(n_ld2));
for j=1:len
    sumcost=sumcost+0.04*Qchp2(j)^2+20*Qchp2(j);
    cons=cons+[Qchp2(j)==-d2(1)*4.182*10^-3*(Tssr2(j)-Trsr2(j))];
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp2(j)-Qchp2(j-1)<=Qmax2*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr2<=Tsmax];
cons=cons+[Trmin<=Trsr2<=Trmax];
for i=1:length(n_ld2)
    cons=cons+[Tsmin<=Tsld2(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld2(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld2)
        Path=Paths2{i};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Tsld2(j,i)==inits*exp(Tloss2(Path(1))*j*tao)*Ms2(i)];
            elseif j*tao>Dy2(Path(1)) && j*tao<=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:(num+1))))
                        cons=cons+[Tsld2(j,i)==inits*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Ms2(i)];
                    end
                end
            else
                cons=cons+[Tsld2(j,i)==Tssr2(ceil((j*tao-sum(Dy2(Path)))/tao))*prod(Sloss2(Path))*Ms2(i)];
            end
        end
    end
    for i=1:length(n_ld2)
        cons=cons+[Trld2(j,i)==Tsld2(j,i)-(Tload(j)/4.182*1000./d2(n_ld2(i)))];
    end
    for k=1:length(n_ld2)
        Path=Pathr2{k};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Trsr_com2(j,k)==initr*exp(Tloss2(Path(1))*j*tao)*Mr2(k)];
            elseif j*tao>Dy2(Path(1)) && j*tao <=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:num+1)))
                        cons=cons+[Trsr_com2(j,k)==initr*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Mr2(k)];
                    end
                end
            else
                cons=cons+[Trsr_com2(j,k)==Trld2(ceil((j*tao-sum(Dy2(Path)))/tao),k)*prod(Sloss2(Path))*Mr2(k)];
            end
        end
    end
    cons=cons+[Trsr2(j)==sum(Trsr_com2(j,:))];
end 

%DHN3
Qchp3=sdpvar(len,1);
Tssr3=sdpvar(len,1);
Trsr3=sdpvar(len,1);
Trsr_com3=sdpvar(len,length(n_ld1));
Tsld3=sdpvar(len,length(n_ld1));
Trld3=sdpvar(len,length(n_ld1));
for j=1:len
    sumcost=sumcost+0.04*Qchp3(j)^2+20*Qchp3(j);
    cons=cons+[Qchp3(j)==-d1(1)*4.182*10^-3*(Tssr3(j)-Trsr3(j))];
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp3(j)-Qchp3(j-1)<=Qmax1*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr3<=Tsmax];
cons=cons+[Trmin<=Trsr3<=Trmax];
for i=1:length(n_ld1)
    cons=cons+[Tsmin<=Tsld3(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld3(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld1)
        Path=Paths1{i};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Tsld3(j,i)==inits*exp(Tloss1(Path(1))*j*tao)*Ms1(i)];
            elseif j*tao>Dy1(Path(1)) && j*tao<=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:(num+1))))
                        cons=cons+[Tsld3(j,i)==inits*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Ms1(i)];
                    end
                end
            else
                cons=cons+[Tsld3(j,i)==Tssr3(ceil((j*tao-sum(Dy1(Path)))/tao))*prod(Sloss1(Path))*Ms1(i)];
            end
        end
    end
    for i=1:length(n_ld1)
        cons=cons+[Trld3(j,i)==Tsld3(j,i)-(Tload(j)/4.182*1000./d1(n_ld1(i)))];
    end
    for k=1:length(n_ld1)
        Path=Pathr1{k};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Trsr_com3(j,k)==initr*exp(Tloss1(Path(1))*j*tao)*Mr1(k)];
            elseif j*tao>Dy1(Path(1)) && j*tao <=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:num+1)))
                        cons=cons+[Trsr_com3(j,k)==initr*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Mr1(k)];
                    end
                end
            else
                cons=cons+[Trsr_com3(j,k)==Trld3(ceil((j*tao-sum(Dy1(Path)))/tao),k)*prod(Sloss1(Path))*Mr1(k)];
            end
        end
    end
    cons=cons+[Trsr3(j)==sum(Trsr_com3(j,:))];
end 

%DHN4
Qchp4=sdpvar(len,1);
Tssr4=sdpvar(len,1);
Trsr4=sdpvar(len,1);
Trsr_com4=sdpvar(len,length(n_ld2));
Tsld4=sdpvar(len,length(n_ld2));
Trld4=sdpvar(len,length(n_ld2));
for j=1:len
    sumcost=sumcost+0.04*Qchp4(j)^2+20*Qchp4(j);
    cons=cons+[Qchp4(j)==-d2(1)*4.182*10^-3*(Tssr4(j)-Trsr4(j))];
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp4(j)-Qchp4(j-1)<=Qmax2*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr4<=Tsmax];
cons=cons+[Trmin<=Trsr4<=Trmax];
for i=1:length(n_ld2)
    cons=cons+[Tsmin<=Tsld4(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld4(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld2)
        Path=Paths2{i};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Tsld4(j,i)==inits*exp(Tloss2(Path(1))*j*tao)*Ms2(i)];
            elseif j*tao>Dy2(Path(1)) && j*tao<=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:(num+1))))
                        cons=cons+[Tsld4(j,i)==inits*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Ms2(i)];
                    end
                end
            else
                cons=cons+[Tsld4(j,i)==Tssr4(ceil((j*tao-sum(Dy2(Path)))/tao))*prod(Sloss2(Path))*Ms2(i)];
            end
        end
    end
    for i=1:length(n_ld2)
        cons=cons+[Trld4(j,i)==Tsld4(j,i)-(Tload(j)/4.182*1000./d2(n_ld2(i)))];
    end
    for k=1:length(n_ld2)
        Path=Pathr2{k};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Trsr_com4(j,k)==initr*exp(Tloss2(Path(1))*j*tao)*Mr2(k)];
            elseif j*tao>Dy2(Path(1)) && j*tao <=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:num+1)))
                        cons=cons+[Trsr_com4(j,k)==initr*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Mr2(k)];
                    end
                end
            else
                cons=cons+[Trsr_com4(j,k)==Trld4(ceil((j*tao-sum(Dy2(Path)))/tao),k)*prod(Sloss2(Path))*Mr2(k)];
            end
        end
    end
    cons=cons+[Trsr4(j)==sum(Trsr_com4(j,:))];
end 

%DHN5
Qchp5=sdpvar(len,1);
Tssr5=sdpvar(len,1);
Trsr5=sdpvar(len,1);
Trsr_com5=sdpvar(len,length(n_ld2));
Tsld5=sdpvar(len,length(n_ld2));
Trld5=sdpvar(len,length(n_ld2));
for j=1:len
    sumcost=sumcost+0.04*Qchp5(j)^2+20*Qchp5(j);
    cons=cons+[Qchp5(j)==-d2(1)*4.182*10^-3*(Tssr5(j)-Trsr5(j))];
    if j>=2
        cons=cons+[-300*0.05<=Qchp5(j)-Qchp5(j-1)<=300*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr5<=Tsmax];
cons=cons+[Trmin<=Trsr5<=Trmax];
for i=1:length(n_ld2)
    cons=cons+[Tsmin<=Tsld5(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld5(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld2)
        Path=Paths2{i};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Tsld5(j,i)==inits*exp(Tloss2(Path(1))*j*tao)*Ms2(i)];
            elseif j*tao>Dy2(Path(1)) && j*tao<=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:(num+1))))
                        cons=cons+[Tsld5(j,i)==inits*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Ms2(i)];
                    end
                end
            else
                cons=cons+[Tsld5(j,i)==Tssr5(ceil((j*tao-sum(Dy2(Path)))/tao))*prod(Sloss2(Path))*Ms2(i)];
            end
        end
    end
    for i=1:length(n_ld2)
        cons=cons+[Trld5(j,i)==Tsld5(j,i)-(Tload(j)/4.182*1000./d2(n_ld2(i)))];
    end
    for k=1:length(n_ld2)
        Path=Pathr2{k};
        if sum(Path)~=0
            if j*tao<=Dy2(Path(1))
                cons=cons+[Trsr_com5(j,k)==initr*exp(Tloss2(Path(1))*j*tao)*Mr2(k)];
            elseif j*tao>Dy2(Path(1)) && j*tao <=sum(Dy2(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy2(Path(1:num))) && j*tao<sum(Dy2(Path(1:num+1)))
                        cons=cons+[Trsr_com5(j,k)==initr*prod(Sloss2(Path(1:num)))*exp(Tloss2(Path(num+1))*(j*tao-sum(Dy2(Path(1:num)))))*Mr2(k)];
                    end
                end
            else
                cons=cons+[Trsr_com5(j,k)==Trld5(ceil((j*tao-sum(Dy2(Path)))/tao),k)*prod(Sloss2(Path))*Mr2(k)];
            end
        end
    end
    cons=cons+[Trsr5(j)==sum(Trsr_com5(j,:))];
end 

%DHN6
Qchp6=sdpvar(len,1);
Tssr6=sdpvar(len,1);
Trsr6=sdpvar(len,1);
Trsr_com6=sdpvar(len,length(n_ld1));
Tsld6=sdpvar(len,length(n_ld1));
Trld6=sdpvar(len,length(n_ld1));
for j=1:len
    sumcost=sumcost+0.04*Qchp6(j)^2+20*Qchp6(j);
    cons=cons+[Qchp6(j)==-d1(1)*4.182*10^-3*(Tssr6(j)-Trsr6(j))];
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp6(j)-Qchp6(j-1)<=Qmax1*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr6<=Tsmax];
cons=cons+[Trmin<=Trsr6<=Trmax];
for i=1:length(n_ld1)
    cons=cons+[Tsmin<=Tsld6(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld6(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld1)
        Path=Paths1{i};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Tsld6(j,i)==inits*exp(Tloss1(Path(1))*j*tao)*Ms1(i)];
            elseif j*tao>Dy1(Path(1)) && j*tao<=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:(num+1))))
                        cons=cons+[Tsld6(j,i)==inits*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Ms1(i)];
                    end
                end
            else
                cons=cons+[Tsld6(j,i)==Tssr6(ceil((j*tao-sum(Dy1(Path)))/tao))*prod(Sloss1(Path))*Ms1(i)];
            end
        end
    end
    for i=1:length(n_ld1)
        cons=cons+[Trld6(j,i)==Tsld6(j,i)-(Tload(j)/4.182*1000./d1(n_ld1(i)))];
    end
    for k=1:length(n_ld1)
        Path=Pathr1{k};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Trsr_com6(j,k)==initr*exp(Tloss1(Path(1))*j*tao)*Mr1(k)];
            elseif j*tao>Dy1(Path(1)) && j*tao <=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:num+1)))
                        cons=cons+[Trsr_com6(j,k)==initr*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Mr1(k)];
                    end
                end
            else
                cons=cons+[Trsr_com6(j,k)==Trld6(ceil((j*tao-sum(Dy1(Path)))/tao),k)*prod(Sloss1(Path))*Mr1(k)];
            end
        end
    end
    cons=cons+[Trsr6(j)==sum(Trsr_com6(j,:))];
end 

%DHN7
Qchp7=sdpvar(len,1);
Tssr7=sdpvar(len,1);
Trsr7=sdpvar(len,1);
Trsr_com7=sdpvar(len,length(n_ld1));
Tsld7=sdpvar(len,length(n_ld1));
Trld7=sdpvar(len,length(n_ld1));
for j=1:len
    sumcost=sumcost+0.04*Qchp7(j)^2+20*Qchp7(j);
    cons=cons+[Qchp7(j)==-d1(1)*4.182*10^-3*(Tssr7(j)-Trsr7(j))];
    if j>=2
        cons=cons+[-100*0.05<=Qchp7(j)-Qchp7(j-1)<=100*0.05];
    end    
end
cons=cons+[Tsmin<=Tssr7<=Tsmax];
cons=cons+[Trmin<=Trsr7<=Trmax];
for i=1:length(n_ld1)
    cons=cons+[Tsmin<=Tsld7(:,i)<=Tsmax];
    cons=cons+[Trmin<=Trld7(:,i)<=Trmax];
end
for j=1:len
    for i=1:length(n_ld1)
        Path=Paths1{i};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Tsld7(j,i)==inits*exp(Tloss1(Path(1))*j*tao)*Ms1(i)];
            elseif j*tao>Dy1(Path(1)) && j*tao<=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:(num+1))))
                        cons=cons+[Tsld7(j,i)==inits*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Ms1(i)];
                    end
                end
            else
                cons=cons+[Tsld7(j,i)==Tssr7(ceil((j*tao-sum(Dy1(Path)))/tao))*prod(Sloss1(Path))*Ms1(i)];
            end
        end
    end
    for i=1:length(n_ld1)
        cons=cons+[Trld7(j,i)==Tsld7(j,i)-(Tload(j)/4.182*1000./d1(n_ld1(i)))];
    end
    for k=1:length(n_ld1)
        Path=Pathr1{k};
        if sum(Path)~=0
            if j*tao<=Dy1(Path(1))
                cons=cons+[Trsr_com7(j,k)==initr*exp(Tloss1(Path(1))*j*tao)*Mr1(k)];
            elseif j*tao>Dy1(Path(1)) && j*tao <=sum(Dy1(Path))
                for num=1:length(Path)-1
                    if j*tao>sum(Dy1(Path(1:num))) && j*tao<sum(Dy1(Path(1:num+1)))
                        cons=cons+[Trsr_com7(j,k)==initr*prod(Sloss1(Path(1:num)))*exp(Tloss1(Path(num+1))*(j*tao-sum(Dy1(Path(1:num)))))*Mr1(k)];
                    end
                end
            else
                cons=cons+[Trsr_com7(j,k)==Trld7(ceil((j*tao-sum(Dy1(Path)))/tao),k)*prod(Sloss1(Path))*Mr1(k)];
            end
        end
    end
    cons=cons+[Trsr7(j)==sum(Trsr_com7(j,:))];
end 

%% ���Լ��
cons=cons+[zeros(len,1)<=Qchp1<=ones(len,1)*Qmax1];%dhn1
cons=cons+[zeros(len,1)<=Pg(54,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(54,:)'<=Qmax1-0.1*Qchp1];
   
cons=cons+[zeros(len,1)<=Qchp2<=ones(len,1)*Qmax2];%dhn2
cons=cons+[zeros(len,1)<=Pg(61,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp2<=Pg(61,:)'<=Qmax2-0.1*Qchp2];

cons=cons+[zeros(len,1)<=Qchp3<=ones(len,1)*Qmax1];%dhn3
cons=cons+[zeros(len,1)<=Pg(103,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(103,:)'<=Qmax1-0.1*Qchp3];

cons=cons+[zeros(len,1)<=Qchp4<=ones(len,1)*Qmax2];%dhn4
cons=cons+[zeros(len,1)<=Pg(49,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp4<=Pg(49,:)'<=Qmax2-0.1*Qchp4];

cons=cons+[zeros(len,1)<=Qchp5<=ones(len,1)*300];%dhn5
cons=cons+[zeros(len,1)<=Pg(25,:)'<=ones(len,1)*300];
cons=cons+[0.8*Qchp5<=Pg(25,:)'<=300-0.1*Qchp5];

cons=cons+[zeros(len,1)<=Qchp6<=ones(len,1)*Qmax1];%dhn6
cons=cons+[zeros(len,1)<=Pg(111,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp6<=Pg(111,:)'<=Qmax1-0.1*Qchp6];

cons=cons+[zeros(len,1)<=Qchp7<=ones(len,1)*100];%dhn7
cons=cons+[zeros(len,1)<=Pg(12,:)'<=ones(len,1)*100];
cons=cons+[0.8*Qchp7<=Pg(12,:)'<=100-0.1*Qchp7];
%% ��ⲿ��
for k=1:len
    for j=1:N_gen
        sumcost=sumcost+Pg(mpc.gen(j,1),k)^2*mpc.gencost(j,5)...
            +Pg(mpc.gen(j,1),k)*mpc.gencost(j,6);
    end
end

opt=sdpsettings('solver', 'ipopt', 'verbose', 2);
tic
diag = optimize(cons,sumcost,opt);
toc
if diag.problem == 0
    fprintf('%s%f\n','sumcost = ', value(sumcost));
    Vm=value(Vm);Va=value(Va);
    Pl=value(Pl);Ql=value(Ql);
    Pg=value(Pg);Qg=value(Qg);
    Tssr1=value(Tssr1);Trsr1=value(Trsr1);
    Tsld1=value(Tsld1);Trld1=value(Trld1);
    Qchp1=value(Qchp1);
    Tssr2=value(Tssr2);Trsr2=value(Trsr2);
    Tsld2=value(Tsld2);Trld2=value(Trld2);
    Qchp2=value(Qchp2);
    Tssr3=value(Tssr3);Trsr3=value(Trsr3);
    Tsld3=value(Tsld3);Trld3=value(Trld3);
    Qchp3=value(Qchp3);
    Tssr4=value(Tssr4);Trsr4=value(Trsr4);
    Tsld4=value(Tsld4);Trld4=value(Trld4);
    Qchp4=value(Qchp4);
    Tssr5=value(Tssr5);Trsr5=value(Trsr5);
    Tsld5=value(Tsld5);Trld5=value(Trld5);
    Qchp5=value(Qchp5);
    Tssr6=value(Tssr6);Trsr6=value(Trsr6);
    Tsld6=value(Tsld6);Trld6=value(Trld6);
    Qchp6=value(Qchp6);
    Tssr7=value(Tssr7);Trsr7=value(Trsr7);
    Tsld7=value(Tsld7);Trld7=value(Trld7);
    Qchp7=value(Qchp7);
else
    yalmiperror(diag.problem)
end
