function [n_source,n_load,n_notl,n_load_true,n_slack,n_node,n_branch] =reldata1(node,pipe)

NN=max(node(:,1));%�ڵ���
n_slack=find(node(:,5)==0);%ƽ��ڵ�
n_source=find(node(:,2)<0);%Դ�ڵ�
% n_source=[n_slack;n_source];
n_load=find(node(:,5)==1);
n_branch=max(pipe(:,1));
n_node=max(node(:,1));
n_load_true=[];
n_notl=[];

for j=1:NN
    if node(j,5)==1%��Դ��
        if node(j,6)~=0%��ʵ���ɵ�
            n_load_true=[n_load_true;j];
        end
    end
    if node(j,6)<=0%����ʵ���ɵ�
        n_notl=[n_notl;j];
    end
end
            

end

