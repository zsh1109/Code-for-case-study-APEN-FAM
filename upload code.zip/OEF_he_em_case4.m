clc,clear
%% OEFÄÜÁ÷
sumcost=0;%×Ü·ÑÓÃ
len=72;
mpc=case118;

%% µçÁ¦²¿·Ö
Pd=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','electric load');%电负荷比�?
Pd=Pd(:,1:2:143);%ÓÐ¹¦¸ººÉ
%·¢µç»ú³É±¾ÓëÈÝÁ¿²ÎÊý
loc_chp=[54;61;103;49;25;111;12];
Y=full(makeYbus(mpc));
G=real(Y);
B=imag(Y);
N_bus=size(mpc.bus,1);
N_gen=size(mpc.gen,1);
N_branch=size(mpc.branch,1);
cof=zeros(118,1);
for j=1:N_bus
    if mpc.bus(j,3)~=0
        cof=mpc.bus(j,4)/mpc.bus(j,3);
    end
end
Qd=Pd.*cof;%¸ººÉÎÞ¹¦
flag_con1={};%Óë½ÚµãÏàÁ¬µÄÖ§Â·¼¯
flag_con2={};
for j=1:N_bus
    loc1=find(mpc.branch(:,1)==j);
    loc2=find(mpc.branch(:,2)==j);
    flag_con1{j}=sort(loc1);
    flag_con2{j}=sort(loc2);
end
%Éú³ÉÖ§Â·¹¦ÂÊÏÞ
set_hv=find(mpc.bus(:,10)==345);
Smax=zeros(N_branch,1);
for j=1:N_branch
    if ismember(mpc.branch(j,1),set_hv)==1 | ismember(mpc.branch(j,2),set_hv)==1
        Smax(j)=1000;
    else
        Smax(j)=200;
    end
end
loc_pq=find(mpc.bus(:,2)==1);
loc_sr=find(mpc.bus(:,2)~=1);
loc_gt1=mpc.gen(:,1);
loc_gt1([22;26;46;21;11;51;6])=[];%ÆÕÍ¨·¢µç»ú±àºÅ
loc_gt2=(1:N_gen)';
loc_gt2([22;26;46;21;11;51;6])=[];%ÆÕÍ¨·¢µç»ú±àºÅ
%½Úµã¹¦ÂÊ¡¢µçÑ¹ÐÅÏ¢
Pg=sdpvar(N_bus,len);
Qg=sdpvar(N_bus,len);
Vm=sdpvar(N_bus,len);
Va=sdpvar(N_bus,len);
Pl=sdpvar(N_branch,len);
Ql=sdpvar(N_branch,len);

cons=[Va(69,:)==zeros(1,len)];
for j=1:len
    cons=cons+[Pg(loc_pq,j)==zeros(length(loc_pq),1);
        Qg(loc_pq,j)==zeros(length(loc_pq),1);%¸ººÉ½ÚµãÓÐ¹¦ÎÞ¹¦
        mpc.gen(:,5)<=Qg(loc_sr,j)<=mpc.gen(:,4);
        mpc.gen(loc_gt2,10)<=Pg(loc_gt1,j)<=mpc.gen(loc_gt2,9);%·¢µç»ú¹¦ÂÊÉÏÏÂÏÞ
        mpc.bus(:,13)<=Vm(:,j)<=mpc.bus(:,12);%µçÑ¹ÉÏÏÂÏÞ
        -pi/2*ones(N_bus,1)<=Va(:,j)<=pi/2*ones(N_bus,1);
        Pl(:,j).^2+Ql(:,j).^2<=Smax.^2;
        ];
end
for j=1:N_branch%Ö§Â·¹¦ÂÊ
    f=mpc.branch(j,1);%Ê×Ä©½Úµã
    t=mpc.branch(j,2);
    for k=1:len
        cons=cons+[D
        Pl(j,k)==-(G(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-B(f,t)*(Va(f,k)-Va(t,k))+1/2*G(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100;
        Ql(j,k)==-(-B(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-G(f,t)*(Va(f,k)-Va(t,k))-1/2*B(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100];
    end
end

for j=1:N_bus
    loc1=flag_con1{j};
    loc2=flag_con2{j};
    for k=1:len
        cons=cons+[
        Pg(j,k)==Pd(j,k)+sum(Pl(loc1,k))-sum(Pl(loc2,k))+sum(G(j,:))*Vm(j,k)^2*100;
        Qg(j,k)==Qd(j,k)+sum(Ql(loc1,k))-sum(Ql(loc2,k))-sum(B(j,:))*Vm(j,k)^2*100];
    end
end

%% ÈÈÁ¦²¿·Ö
node1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node5');%DHN1,51节点
pipe1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe5');
node2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node4');%DHN3,198节点
pipe2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe4');
data=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','Heat load3');
tao=20*60;h=100;data=data(1:2:143,:);
Tload=data(:,1);Tsmin=data(:,2);Trmin=data(:,4);
Tsmax=data(:,3);Trmax=data(:,5);
inits=100;initr=60;

%51½Úµã
l1=pipe1(:,4);lamda1=pipe1(:,6);m1=pipe1(:,8);Qmax1=60;d1=node1(:,6);v1=pipe1(:,9);
[n_sr1,n_ns1,n_nl1,n_ld1,n_sl1,n_nd1,n_br1]=reldata1(node1,pipe1);
M1=round(l1/h)+1;outlet1=cumsum(M1);inlet1=outlet1-M1+1;%Ö§Â·Ê×¶Ë±ê¼Ç
k11=(v1*tao./h-1-v1*tao/2./m1/4182./lamda1)./(v1*tao./h+1+v1*tao/2./m1/4182./lamda1);
k21=(1-v1*tao./h-v1*tao/2./m1/4182./lamda1)./(v1*tao./h+1+v1*tao/2./m1/4182./lamda1);
k31=(1+v1*tao./h-v1*tao/2./m1/4182./lamda1)./(v1*tao./h+1+v1*tao/2./m1/4182./lamda1);
%199½Úµã
l2=pipe2(:,4);lamda2=pipe2(:,6);m2=pipe2(:,8);Qmax2=220;d2=node2(:,6);v2=pipe2(:,9);
[n_sr2,n_ns2,n_nl2,n_ld2,n_sl2,n_nd2,n_br2]=reldata1(node2,pipe2);
M2=round(l2/h)+1;outlet2=cumsum(M2);inlet2=outlet2-M2+1;%Ö§Â·Ê×¶Ë±ê¼Ç
k12=(v2*tao./h-1-v2*tao/2./m2/4182./lamda2)./(v2*tao./h+1+v2*tao/2./m2/4182./lamda2);
k22=(1-v2*tao./h-v2*tao/2./m2/4182./lamda2)./(v2*tao./h+1+v2*tao/2./m2/4182./lamda2);
k32=(1+v2*tao./h-v2*tao/2./m2/4182./lamda2)./(v2*tao./h+1+v2*tao/2./m2/4182./lamda2);

%% Â·¾¶-DHN1
for num_hn=1:2
    eval(['pipe=pipe',num2str(num_hn),';']);eval(['n_nd=n_nd',num2str(num_hn),';']);
    eval(['n_sr=n_sr',num2str(num_hn),';']);eval(['n_ld=n_ld',num2str(num_hn),';']);
    %¹©Ë®Íø
    Paths={};
    Paths{1}=n_sr;
    temp_know=n_sr;%ÒÑÖªÎÂ¶Èµã
    temps=n_sr;
    num=1;
    while length(temp_know)~=n_nd
        temp_lv=[];
        for j=1:length(temps)
            loc_pipe=find(pipe(:,2)==temps(j));%ÒÔtempsÎªÆðµãµÄ¹ÜµÀ
            down_node=pipe(loc_pipe,3);%loc_pipeµÄÄ©¶Ë½Úµã£¬ÅÐ¶Ïdown_nodeÖÐÄÇÐ©¿ÉÒÔÇó½â
            for k=1:length(down_node)
                in_pipe=find(pipe(:,3)==down_node(k));%Á÷Èëdown_node(k)µÄ¹ÜµÀ¼¯
                in_node=unique(pipe(in_pipe,2));%Á÷Èëdown_node(k)µÄÉÏÓÎ½Úµã¼¯
                flag=0;
                for i=1:length(in_node)
                    if sum(ismember(temp_know,in_node(i)))==1
                        flag=flag+1;
                    end
                end
                if flag==length(in_node)
                    temp_lv=[temp_lv;down_node(k)];
                end
            end
        end
        temps=unique(temp_lv);
        temp_know=[temp_know;temps];
        Paths{num+1}=temps;
        num=num+1;                
    end
    Paths=Paths';  
    %»ØË®Íø
    Pathr={};
    Pathr{1}=n_ld;
    temp_know=n_ld;%ÒÑÖªÎÂ¶Èµã
    tempr=n_ld;
    num=1;
    while length(temp_know)~=n_nd
        temp_lv=[];
        for j=1:length(tempr)
            loc_pipe=find(pipe(:,3)==tempr(j));%ÒÔtempsÎªÆðµãµÄ¹ÜµÀ
            down_node=pipe(loc_pipe,2);%loc_pipeµÄÄ©¶Ë½Úµã£¬ÅÐ¶Ïdown_nodeÖÐÄÇÐ©¿ÉÒÔÇó½â
            for k=1:length(down_node)
                in_pipe=find(pipe(:,2)==down_node(k));%Á÷Èëdown_node(k)µÄ¹ÜµÀ¼¯
                in_node=unique(pipe(in_pipe,3));%Á÷Èëdown_node(k)µÄÉÏÓÎ½Úµã¼¯
                flag=0;
                for i=1:length(in_node)
                    if sum(ismember(temp_know,in_node(i)))==1
                        flag=flag+1;
                    end
                end
                if flag==length(in_node)
                    temp_lv=[temp_lv;down_node(k)];
                end
            end
        end
        tempr=unique(temp_lv);
        temp_know=[temp_know;tempr];
        Pathr{num+1}=tempr;
        num=num+1;                
    end
    Pathr=Pathr';
    eval(['Paths',num2str(num_hn),'=Paths;']);
    eval(['Pathr',num2str(num_hn),'=Pathr;']);
end

%% ÈÈÔ¼Êø
%DHN1
Ts1=sdpvar(len+1,n_nd1);Tr1=sdpvar(len+1,n_nd1);Qchp1=sdpvar(len,1);
Tps1=sdpvar(len+1,outlet1(end));Tpr1=sdpvar(len+1,outlet1(end));

cons=cons+[Tps1(1,:)==inits*ones(1,outlet1(end))];
cons=cons+[Tpr1(1,:)==initr*ones(1,outlet1(end))];
cons=cons+[Ts1(1,:)==inits*ones(1,n_nd1)];
cons=cons+[Tr1(1,:)==initr*ones(1,n_nd1)];
cons=cons+[Qchp1==-d1(1)*4.182*10^-3*(Ts1(2:end,1)-Tr1(2:end,1))];

for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp1(j)^2+20*Qchp1(j);
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp1(j)-Qchp1(j-1)<=Qmax1*0.05];
    end 
end
% for i=1:n_nd1
%     cons=cons+[Tsmin<=Ts1(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr1(2:end,i)<=Trmax];
% end
for i=1:outlet1(end)
    cons=cons+[Tsmin<=Tps1(2:end,i)<=Tsmax;
        Trmin<=Tpr1(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths1)
        path=Paths1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps1(j,inlet1(to_pipe))==Ts1(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M1(loc)-1
                   cons=cons+[Tps1(j,inlet1(loc)+n)==k11(loc)*Tps1(j,inlet1(loc)+n-1)+...
                       k21(loc)*Tps1(j-1,inlet1(loc)+n)+k31(loc)*Tps1(j-1,inlet1(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths1)-1
            next_path=Paths1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,3)==loc);
                cons=cons+[Ts1(j,loc)==m1(in_pipe)'*Tps1(j,outlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr1(j,n_ld1)==Ts1(j,n_ld1)-(Tload(j-1)*ones(length(n_ld1),1)/4.182*10^3./d1(n_ld1))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr1)
        path=Pathr1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr1(j,outlet1(to_pipe))==Tr1(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M1(loc)-1
                   cons=cons+[Tpr1(j,outlet1(loc)-n)==k11(loc)*Tpr1(j,outlet1(loc)-n+1)+...
                       k21(loc)*Tpr1(j-1,outlet1(loc)-n)+k31(loc)*Tpr1(j-1,outlet1(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr1)-1
            next_path=Pathr1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,2)==loc);
                cons=cons+[Tr1(j,loc)==m1(in_pipe)'*Tpr1(j,inlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end 
end

%DHN2
Ts2=sdpvar(len+1,n_nd2);Tr2=sdpvar(len+1,n_nd2);Qchp2=sdpvar(len,1);
Tps2=sdpvar(len+1,outlet2(end));Tpr2=sdpvar(len+1,outlet2(end));

cons=cons+[Tps2(1,:)==inits*ones(1,outlet2(end))];
cons=cons+[Tpr2(1,:)==initr*ones(1,outlet2(end))];
cons=cons+[Ts2(1,:)==inits*ones(1,n_nd2)];
cons=cons+[Tr2(1,:)==initr*ones(1,n_nd2)];
cons=cons+[Qchp2==-d2(1)*4.182*10^-3*(Ts2(2:end,1)-Tr2(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp2(j)^2+20*Qchp2(j);
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp2(j)-Qchp2(j-1)<=Qmax2*0.05]; 
    end
end
% for i=1:n_nd2
%     cons=cons+[Tsmin<=Ts2(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr2(2:end,i)<=Trmax];
% end
for i=1:outlet2(end)
    cons=cons+[Tsmin<=Tps2(2:end,i)<=Tsmax;
        Trmin<=Tpr2(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths2)
        path=Paths2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps2(j,inlet2(to_pipe))==Ts2(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M2(loc)-1
                   cons=cons+[Tps2(j,inlet2(loc)+n)==k12(loc)*Tps2(j,inlet2(loc)+n-1)+...
                       k22(loc)*Tps2(j-1,inlet2(loc)+n)+k32(loc)*Tps2(j-1,inlet2(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths2)-1
            next_path=Paths2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,3)==loc);
                cons=cons+[Ts2(j,loc)==m2(in_pipe)'*Tps2(j,outlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr2(j,n_ld2)==Ts2(j,n_ld2)-(Tload(j-1)*ones(length(n_ld2),1)/4.182*10^3./d2(n_ld2))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr2)
        path=Pathr2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr2(j,outlet2(to_pipe))==Tr2(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M2(loc)-1
                   cons=cons+[Tpr2(j,outlet2(loc)-n)==k12(loc)*Tpr2(j,outlet2(loc)-n+1)+...
                       k22(loc)*Tpr2(j-1,outlet2(loc)-n)+k32(loc)*Tpr2(j-1,outlet2(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr2)-1
            next_path=Pathr2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,2)==loc);
                cons=cons+[Tr2(j,loc)==m2(in_pipe)'*Tpr2(j,inlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end 
end

%DHN3
Ts3=sdpvar(len+1,n_nd1);Tr3=sdpvar(len+1,n_nd1);Qchp3=sdpvar(len,1);
Tps3=sdpvar(len+1,outlet1(end));Tpr3=sdpvar(len+1,outlet1(end));

cons=cons+[Tps3(1,:)==inits*ones(1,outlet1(end))];
cons=cons+[Tpr3(1,:)==initr*ones(1,outlet1(end))];
cons=cons+[Ts3(1,:)==inits*ones(1,n_nd1)];
cons=cons+[Tr3(1,:)==initr*ones(1,n_nd1)];
cons=cons+[Qchp3==-d1(1)*4.182*10^-3*(Ts3(2:end,1)-Tr3(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp3(j)^2+20*Qchp3(j);
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp3(j)-Qchp3(j-1)<=Qmax1*0.05]; 
    end
end
% for i=1:n_nd1
%     cons=cons+[Tsmin<=Ts3(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr3(2:end,i)<=Trmax];
% end
for i=1:outlet1(end)
    cons=cons+[Tsmin<=Tps3(2:end,i)<=Tsmax;
        Trmin<=Tpr3(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths1)
        path=Paths1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps3(j,inlet1(to_pipe))==Ts3(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M1(loc)-1
                   cons=cons+[Tps3(j,inlet1(loc)+n)==k11(loc)*Tps3(j,inlet1(loc)+n-1)+...
                       k21(loc)*Tps3(j-1,inlet1(loc)+n)+k31(loc)*Tps3(j-1,inlet1(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths1)-1
            next_path=Paths1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,3)==loc);
                cons=cons+[Ts3(j,loc)==m1(in_pipe)'*Tps3(j,outlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr3(j,n_ld1)==Ts3(j,n_ld1)-(Tload(j-1)*ones(length(n_ld1),1)/4.182*10^3./d1(n_ld1))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr1)
        path=Pathr1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr3(j,outlet1(to_pipe))==Tr3(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M1(loc)-1
                   cons=cons+[Tpr3(j,outlet1(loc)-n)==k11(loc)*Tpr3(j,outlet1(loc)-n+1)+...
                       k21(loc)*Tpr3(j-1,outlet1(loc)-n)+k31(loc)*Tpr3(j-1,outlet1(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr1)-1
            next_path=Pathr1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,2)==loc);
                cons=cons+[Tr3(j,loc)==m1(in_pipe)'*Tpr3(j,inlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end 
end


%DHN4
Ts4=sdpvar(len+1,n_nd2);Tr4=sdpvar(len+1,n_nd2);Qchp4=sdpvar(len,1);
Tps4=sdpvar(len+1,outlet2(end));Tpr4=sdpvar(len+1,outlet2(end));

cons=cons+[Tps4(1,:)==inits*ones(1,outlet2(end))];
cons=cons+[Tpr4(1,:)==initr*ones(1,outlet2(end))];
cons=cons+[Ts4(1,:)==inits*ones(1,n_nd2)];
cons=cons+[Tr4(1,:)==initr*ones(1,n_nd2)];
cons=cons+[Qchp4==-d2(1)*4.182*10^-3*(Ts4(2:end,1)-Tr4(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp4(j)^2+20*Qchp4(j);
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp4(j)-Qchp4(j-1)<=Qmax2*0.05]; 
    end
end
% for i=1:n_nd2
%     cons=cons+[Tsmin<=Ts4(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr4(2:end,i)<=Trmax];
% end
for i=1:outlet2(end)
    cons=cons+[Tsmin<=Tps4(2:end,i)<=Tsmax;
        Trmin<=Tpr4(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths2)
        path=Paths2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps4(j,inlet2(to_pipe))==Ts4(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M2(loc)-1
                   cons=cons+[Tps4(j,inlet2(loc)+n)==k12(loc)*Tps4(j,inlet2(loc)+n-1)+...
                       k22(loc)*Tps4(j-1,inlet2(loc)+n)+k32(loc)*Tps4(j-1,inlet2(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths2)-1
            next_path=Paths2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,3)==loc);
                cons=cons+[Ts4(j,loc)==m2(in_pipe)'*Tps4(j,outlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr4(j,n_ld2)==Ts4(j,n_ld2)-(Tload(j-1)*ones(length(n_ld2),1)/4.182*10^3./d2(n_ld2))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr2)
        path=Pathr2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr4(j,outlet2(to_pipe))==Tr4(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M2(loc)-1
                   cons=cons+[Tpr4(j,outlet2(loc)-n)==k12(loc)*Tpr4(j,outlet2(loc)-n+1)+...
                       k22(loc)*Tpr4(j-1,outlet2(loc)-n)+k32(loc)*Tpr4(j-1,outlet2(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr2)-1
            next_path=Pathr2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,2)==loc);
                cons=cons+[Tr4(j,loc)==m2(in_pipe)'*Tpr4(j,inlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end 
end

%DHN5
Ts5=sdpvar(len+1,n_nd2);Tr5=sdpvar(len+1,n_nd2);Qchp5=sdpvar(len,1);
Tps5=sdpvar(len+1,outlet2(end));Tpr5=sdpvar(len+1,outlet2(end));

cons=cons+[Tps5(1,:)==inits*ones(1,outlet2(end))];
cons=cons+[Tpr5(1,:)==initr*ones(1,outlet2(end))];
cons=cons+[Ts5(1,:)==inits*ones(1,n_nd2)];
cons=cons+[Tr5(1,:)==initr*ones(1,n_nd2)];
cons=cons+[Qchp5==-d2(1)*4.182*10^-3*(Ts5(2:end,1)-Tr5(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    if j>=2
        sumcost=sumcost+0.04*Qchp5(j)^2+20*Qchp5(j);
    end
    cons=cons+[-300*0.05<=Qchp5(j)-Qchp5(j-1)<=300*0.05]; 
end
% for i=1:n_nd2
%     cons=cons+[Tsmin<=Ts5(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr5(2:end,i)<=Trmax];
% end
for i=1:outlet2(end)
    cons=cons+[Tsmin<=Tps5(2:end,i)<=Tsmax;
        Trmin<=Tpr5(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths2)
        path=Paths2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps5(j,inlet2(to_pipe))==Ts5(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M2(loc)-1
                   cons=cons+[Tps5(j,inlet2(loc)+n)==k12(loc)*Tps5(j,inlet2(loc)+n-1)+...
                       k22(loc)*Tps5(j-1,inlet2(loc)+n)+k32(loc)*Tps5(j-1,inlet2(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths2)-1
            next_path=Paths2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,3)==loc);
                cons=cons+[Ts5(j,loc)==m2(in_pipe)'*Tps5(j,outlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr5(j,n_ld2)==Ts5(j,n_ld2)-(Tload(j-1)*ones(length(n_ld2),1)/4.182*10^3./d2(n_ld2))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr2)
        path=Pathr2{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe2(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr5(j,outlet2(to_pipe))==Tr5(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M2(loc)-1
                   cons=cons+[Tpr5(j,outlet2(loc)-n)==k12(loc)*Tpr5(j,outlet2(loc)-n+1)+...
                       k22(loc)*Tpr5(j-1,outlet2(loc)-n)+k32(loc)*Tpr5(j-1,outlet2(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr2)-1
            next_path=Pathr2{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe2(:,2)==loc);
                cons=cons+[Tr5(j,loc)==m2(in_pipe)'*Tpr5(j,inlet2(in_pipe))'/sum(m2(in_pipe))];
            end
        end  
    end 
end

%DHN6
Ts6=sdpvar(len+1,n_nd1);Tr6=sdpvar(len+1,n_nd1);Qchp6=sdpvar(len,1);
Tps6=sdpvar(len+1,outlet1(end));Tpr6=sdpvar(len+1,outlet1(end));

cons=cons+[Tps6(1,:)==inits*ones(1,outlet1(end))];
cons=cons+[Tpr6(1,:)==initr*ones(1,outlet1(end))];
cons=cons+[Ts6(1,:)==inits*ones(1,n_nd1)];
cons=cons+[Tr6(1,:)==initr*ones(1,n_nd1)];
cons=cons+[Qchp6==-d1(1)*4.182*10^-3*(Ts6(2:end,1)-Tr6(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp6(j)^2+20*Qchp6(j);
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp6(j)-Qchp6(j-1)<=Qmax1*0.05]; 
    end
end
% for i=1:n_nd1
%     cons=cons+[Tsmin<=Ts6(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr6(2:end,i)<=Trmax];
% end
for i=1:outlet1(end)
    cons=cons+[Tsmin<=Tps6(2:end,i)<=Tsmax;
        Trmin<=Tpr6(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths1)
        path=Paths1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps6(j,inlet1(to_pipe))==Ts6(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M1(loc)-1
                   cons=cons+[Tps6(j,inlet1(loc)+n)==k11(loc)*Tps6(j,inlet1(loc)+n-1)+...
                       k21(loc)*Tps6(j-1,inlet1(loc)+n)+k31(loc)*Tps6(j-1,inlet1(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths1)-1
            next_path=Paths1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,3)==loc);
                cons=cons+[Ts6(j,loc)==m1(in_pipe)'*Tps6(j,outlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr6(j,n_ld1)==Ts6(j,n_ld1)-(Tload(j-1)*ones(length(n_ld1),1)/4.182*10^3./d1(n_ld1))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr1)
        path=Pathr1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr6(j,outlet1(to_pipe))==Tr6(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M1(loc)-1
                   cons=cons+[Tpr6(j,outlet1(loc)-n)==k11(loc)*Tpr6(j,outlet1(loc)-n+1)+...
                       k21(loc)*Tpr6(j-1,outlet1(loc)-n)+k31(loc)*Tpr6(j-1,outlet1(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr1)-1
            next_path=Pathr1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,2)==loc);
                cons=cons+[Tr6(j,loc)==m1(in_pipe)'*Tpr6(j,inlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end 
end

%DHN7
Ts7=sdpvar(len+1,n_nd1);Tr7=sdpvar(len+1,n_nd1);Qchp7=sdpvar(len,1);
Tps7=sdpvar(len+1,outlet1(end));Tpr7=sdpvar(len+1,outlet1(end));

cons=cons+[Tps7(1,:)==inits*ones(1,outlet1(end))];
cons=cons+[Tpr7(1,:)==initr*ones(1,outlet1(end))];
cons=cons+[Ts7(1,:)==inits*ones(1,n_nd1)];
cons=cons+[Tr7(1,:)==initr*ones(1,n_nd1)];
cons=cons+[Qchp7==-d1(1)*4.182*10^-3*(Ts7(2:end,1)-Tr7(2:end,1))];
for j=1:len%Éè±¸Ô¼Êø
    sumcost=sumcost+0.04*Qchp7(j)^2+20*Qchp7(j);
    if j>=2
        cons=cons+[-100*0.05<=Qchp7(j)-Qchp7(j-1)<=100*0.05];
    end 
end
% for i=1:n_nd1
%     cons=cons+[Tsmin<=Ts7(2:end,i)<=Tsmax];
%     cons=cons+[Trmin<=Tr7(2:end,i)<=Trmax];
% end
for i=1:outlet1(end)
    cons=cons+[Tsmin<=Tps7(2:end,i)<=Tsmax;
        Trmin<=Tpr7(2:end,i)<=Trmax];
end
for j=2:len+1
    %¹©Ë®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Paths1)
        path=Paths1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,2)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tps7(j,inlet1(to_pipe))==Ts7(j,path(i))*ones(1,length(to_pipe))];  
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ
               for n=1:M1(loc)-1
                   cons=cons+[Tps7(j,inlet1(loc)+n)==k11(loc)*Tps7(j,inlet1(loc)+n-1)+...
                       k21(loc)*Tps7(j-1,inlet1(loc)+n)+k31(loc)*Tps7(j-1,inlet1(loc)+n-1)];
               end
           end
        end
        %¼ÆËãÓëPaths{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Paths1)-1
            next_path=Paths1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,3)==loc);
                cons=cons+[Ts7(j,loc)==m1(in_pipe)'*Tps7(j,outlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end
    %¹©»ØË®ÎÂ¶ÈñîºÏ
    cons=cons+[Tr7(j,n_ld1)==Ts7(j,n_ld1)-(Tload(j-1)*ones(length(n_ld1),1)/4.182*10^3./d1(n_ld1))'];
    %»ØË®ÍøÎÂ¶È¼ÆËã
    for k=1:length(Pathr1)
        path=Pathr1{k};  
        %¼ÆËãÓëPaths{k}Ö±Á¬µÄ¹ÜµÀÎÂ¶È
        for i=1:length(path)%±éÀú½Úµã  
           to_pipe=find(pipe1(:,3)==path(i));%Á÷³ö¹ÜµÀ£¬ÆäÎÂ¶È¿ÉÒÔ¼ÆËã
           cons=cons+[Tpr7(j,outlet1(to_pipe))==Tr7(j,path(i))*ones(1,length(to_pipe))];   
           for num=1:length(to_pipe)
               loc=to_pipe(num);%¾ßÌå¹ÜµÀ±àºÅ               
               for n=1:M1(loc)-1
                   cons=cons+[Tpr7(j,outlet1(loc)-n)==k11(loc)*Tpr7(j,outlet1(loc)-n+1)+...
                       k21(loc)*Tpr7(j-1,outlet1(loc)-n)+k31(loc)*Tpr7(j-1,outlet1(loc)-n+1)];
               end
           end
        end
        %¼ÆËãÓëPathr{k+1}µÄ½ÚµãÎÂ¶È
        if k<=length(Pathr1)-1
            next_path=Pathr1{k+1};
            for i=1:length(next_path)
                loc=next_path(i);%½Úµã±àºÅ                
                in_pipe=find(pipe1(:,2)==loc);
                cons=cons+[Tr7(j,loc)==m1(in_pipe)'*Tpr7(j,inlet1(in_pipe))'/sum(m1(in_pipe))];
            end
        end  
    end 
end

%% ñîºÏÔ¼Êø
cons=cons+[zeros(len,1)<=Qchp1<=ones(len,1)*Qmax1];%dhn1
cons=cons+[zeros(len,1)<=Pg(54,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(54,:)'<=Qmax1-0.1*Qchp1];
   
cons=cons+[zeros(len,1)<=Qchp2<=ones(len,1)*Qmax2];%dhn2
cons=cons+[zeros(len,1)<=Pg(61,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp2<=Pg(61,:)'<=Qmax2-0.1*Qchp2];

cons=cons+[zeros(len,1)<=Qchp3<=ones(len,1)*Qmax1];%dhn3
cons=cons+[zeros(len,1)<=Pg(103,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(103,:)'<=Qmax1-0.1*Qchp3];

cons=cons+[zeros(len,1)<=Qchp4<=ones(len,1)*Qmax2];%dhn4
cons=cons+[zeros(len,1)<=Pg(49,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp4<=Pg(49,:)'<=Qmax2-0.1*Qchp4];

cons=cons+[zeros(len,1)<=Qchp5<=ones(len,1)*300];%dhn5
cons=cons+[zeros(len,1)<=Pg(25,:)'<=ones(len,1)*300];
cons=cons+[0.8*Qchp5<=Pg(25,:)'<=300-0.1*Qchp5];

cons=cons+[zeros(len,1)<=Qchp6<=ones(len,1)*Qmax1];%dhn6
cons=cons+[zeros(len,1)<=Pg(111,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp6<=Pg(111,:)'<=Qmax1-0.1*Qchp6];

cons=cons+[zeros(len,1)<=Qchp7<=ones(len,1)*100];%dhn6
cons=cons+[zeros(len,1)<=Pg(12,:)'<=ones(len,1)*100];
cons=cons+[0.8*Qchp7<=Pg(12,:)'<=100-0.1*Qchp7];
%% Çó½â²¿·Ö
for k=1:len
    for j=1:N_gen
        sumcost=sumcost+Pg(mpc.gen(j,1),k)^2*mpc.gencost(j,5)...
            +Pg(mpc.gen(j,1),k)*mpc.gencost(j,6);
    end
end

opt=sdpsettings('solver', 'ipopt', 'verbose', 2);
tic
diag = optimize(cons,sumcost,opt);
toc
if diag.problem == 0
    fprintf('%s%f\n','sumcost = ', value(sumcost));
    Vm=value(Vm)';Va=value(Va)';
    Pl=value(Pl)';Ql=value(Ql)';
    Pg=value(Pg)';Qg=value(Qg)';
    Ts1=value(Ts1);Tr1=value(Tr1);
    Qchp1=value(Qchp1);
    Ts2=value(Ts2);Tr2=value(Tr2);
    Qchp2=value(Qchp2);
    Ts3=value(Ts3);Tr3=value(Tr3);
    Qchp3=value(Qchp3);
    Ts4=value(Ts4);Tr4=value(Tr4);
    Qchp4=value(Qchp4);
    Ts5=value(Ts5);Tr5=value(Tr5);
    Qchp5=value(Qchp5);
    Ts6=value(Ts6);Tr6=value(Tr6);
    Qchp6=value(Qchp6);
    Ts7=value(Ts7);Tr7=value(Tr7);
    Qchp7=value(Qchp7);
else
    yalmiperror(diag.problem)
end
