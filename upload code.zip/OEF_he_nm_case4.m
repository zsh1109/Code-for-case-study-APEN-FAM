clc,clear
%% OEF����
sumcost=0;%�ܷ���
len=72;
mpc=case118;

%% ��������
Pd=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','electric load');%�縺�ɱ���
Pd=Pd(:,1:2:143);%�й�����
%������ɱ�����������
% loc_chp=[54;61;103;49;25;111;12];
loc_chp=[54;61;103;49;25;111;12];
Y=full(makeYbus(mpc));
G=real(Y);
B=imag(Y);
N_bus=size(mpc.bus,1);
N_gen=size(mpc.gen,1);
N_branch=size(mpc.branch,1);
cof=zeros(118,1);
for j=1:N_bus
    if mpc.bus(j,3)~=0
        cof=mpc.bus(j,4)/mpc.bus(j,3);
    end
end
Qd=Pd.*cof;%�����޹�
flag_con1={};%��ڵ�������֧·��
flag_con2={};
for j=1:N_bus
    loc1=find(mpc.branch(:,1)==j);
    loc2=find(mpc.branch(:,2)==j);
    flag_con1{j}=sort(loc1);
    flag_con2{j}=sort(loc2);
end
%����֧·������
set_hv=find(mpc.bus(:,10)==345);
Smax=zeros(N_branch,1);
for j=1:N_branch
    if ismember(mpc.branch(j,1),set_hv)==1 | ismember(mpc.branch(j,2),set_hv)==1
        Smax(j)=1000;
    else
        Smax(j)=200;
    end
end
loc_pq=find(mpc.bus(:,2)==1);
loc_sr=find(mpc.bus(:,2)~=1);
loc_gt1=mpc.gen(:,1);
loc_gt1([22;26;46;21;11;51;6])=[];%��ͨ��������
% loc_gt1([22;26;46;21;51;20])=[];%��ͨ��������
loc_gt2=(1:N_gen)';
loc_gt2([22;26;46;21;11;51;6])=[];%��ͨ��������
% loc_gt2([22;26;46;21;51;20])=[];%��ͨ��������
%�ڵ㹦�ʡ���ѹ��Ϣ
Pg=sdpvar(N_bus,len);
Qg=sdpvar(N_bus,len);
Vm=sdpvar(N_bus,len);
Va=sdpvar(N_bus,len);
Pl=sdpvar(N_branch,len);
Ql=sdpvar(N_branch,len);

cons=[Va(69,:)==zeros(1,len)];
for j=1:len
    cons=cons+[Pg(loc_pq,j)==zeros(length(loc_pq),1);
        Qg(loc_pq,j)==zeros(length(loc_pq),1);%���ɽڵ��й��޹�
        mpc.gen(:,5)<=Qg(loc_sr,j)<=mpc.gen(:,4);
        mpc.gen(loc_gt2,10)<=Pg(loc_gt1,j)<=mpc.gen(loc_gt2,9);%���������������
        mpc.bus(:,13)<=Vm(:,j)<=mpc.bus(:,12);%��ѹ������
        -pi/2*ones(N_bus,1)<=Va(:,j)<=pi/2*ones(N_bus,1);
        Pl(:,j).^2+Ql(:,j).^2<=Smax.^2;
        ];
end
for j=1:N_branch%֧·����
    f=mpc.branch(j,1);%��ĩ�ڵ�
    t=mpc.branch(j,2);
    for k=1:len
        cons=cons+[
        Pl(j,k)==-(G(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-B(f,t)*(Va(f,k)-Va(t,k))+1/2*G(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100;
        Ql(j,k)==-(-B(f,t)*(Vm(f,k)^2-Vm(t,k)^2)/2-G(f,t)*(Va(f,k)-Va(t,k))-1/2*B(f,t)*...
            ((Va(f,k)-Va(t,k))^2+(Vm(f,k)-Vm(t,k))^2))*100];
    end
end

for j=1:N_bus
    loc1=flag_con1{j};
    loc2=flag_con2{j};
    for k=1:len
        cons=cons+[
        Pg(j,k)==Pd(j,k)+sum(Pl(loc1,k))-sum(Pl(loc2,k))+sum(G(j,:))*Vm(j,k)^2*100;
        Qg(j,k)==Qd(j,k)+sum(Ql(loc1,k))-sum(Ql(loc2,k))-sum(B(j,:))*Vm(j,k)^2*100];
    end
end

%% ��������
node1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node5');%DHN1,51�ڵ�
pipe1=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe5');
node2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','node4');%DHN3,198�ڵ�
pipe2=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','pipe4');
data=xlsread('C:\�����\�ҵļ����\�ҵļ����\ʱ�����ģ��\Case data.xlsx','Heat load3');
tao=20*60;data=data(1:2:143,:);
Tload=data(:,1);Tsmin=data(:,2);Trmin=data(:,4);
Tsmax=data(:,3);Trmax=data(:,5);
Tsint=100;Trint=60;
rou=960;

%% Parameter
% DHN1
l1=pipe1(:,4);%pipe length,m
lamda1=pipe1(:,6);%resistance
m1=pipe1(:,8);%pipe mass flow rate,kg/s
D1=pipe1(:,5);%diameter,m
v1=pipe1(:,9);%velocity,m/s
d1=node1(:,6);%nodal mass flow rate, kg/s
A1=pi*(D1/2).^2;
phi1=ceil(rou*A1.*l1./m1/tao);
gama1=phi1-1;
R1=phi1.*m1*tao;S1=R1;
Jb1=exp(-tao/960/4182./A1./lamda1.*(gama1+0.5));
miu11=(m1*tao+A1.*l1*rou-S1)./m1/tao.*Jb1;%��Ӧphi
miu21=(R1-A1.*l1*rou)./m1/tao.*Jb1;%��Ӧgama
Qmax1=60;%Maximum capacity of source heat power
% Topology data
[n_sr1,n_ns1,n_nl1,n_ld1,n_sl1,n_nd1,n_br1]=reldata1(node1,pipe1);
[A01,Ab1,As_np1,As_pn1,As1,Ar_np1,Ar_pn1,Ar1]=inc_matrix(pipe1,n_sl1,n_nd1,n_br1);%As_np*m-As_pn*m+d=0

% DHN2
l2=pipe2(:,4);%pipe length,m
lamda2=pipe2(:,6);%resistance
m2=pipe2(:,8);%pipe mass flow rate,kg/s
D2=pipe2(:,5);%diameter,m
v2=pipe2(:,9);%velocity,m/s
d2=node2(:,6);%nodal mass flow rate, kg/s
A2=pi*(D2/2).^2;
phi2=ceil(rou*A2.*l2./m2/tao);
gama2=phi2-1;
R2=phi2.*m2*tao;S2=R2;
Jb2=exp(-tao/960/4182./A2./lamda2.*(gama2+0.5));
miu12=(m2*tao+A2.*l2*rou-S2)./m2/tao.*Jb2;%��Ӧphi
miu22=(R2-A2.*l2*rou)./m2/tao.*Jb2;%��Ӧgama
Qmax2=220;%Maximum capacity of source heat power
% Topology data
[n_sr2,n_ns2,n_nl2,n_ld2,n_sl2,n_nd2,n_br2]=reldata1(node2,pipe2);
[A02,Ab2,As_np2,As_pn2,As2,Ar_np2,Ar_pn2,Ar2]=inc_matrix(pipe2,n_sl2,n_nd2,n_br2);

%% Hydraulic distribution
%DHN1
Mout_s1=diag(As_np1*m1+d1);%mass flow rate leaving from node in supply network
Min_s1=As_pn1*diag(m1);%mass flow rate injecting into node in supply network
Mout_r1=diag(Ar_np1*m1-d1);%mass flow rate leaving from node in return network
Min_r1=Ar_pn1*diag(m1);%mass flow rate injecting into node in return network

%DHN2
Mout_s2=diag(As_np2*m2+d2);%mass flow rate leaving from node in supply network
Min_s2=As_pn2*diag(m2);%mass flow rate injecting into node in supply network
Mout_r2=diag(Ar_np2*m2-d2);%mass flow rate leaving from node in return network
Min_r2=Ar_pn2*diag(m2);%mass flow rate injecting into node in return network

%% Optimization part
%DHN1
Qchp1=sdpvar(len,1);%chp�ȹ���
Tin_s1=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_s1=sdpvar(len,n_br1);
Tin_r1=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_r1=sdpvar(len,n_br1);
Ts1=sdpvar(len,n_nd1);
Tr1=sdpvar(len,n_nd1);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp1(j)^2+20*Qchp1(j);
    cons=cons+[Qchp1(j)==-d1(1)*4.182*10^-3*(Ts1(j,1)-Tr1(j,1))];
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp1(j)-Qchp1(j-1)<=Qmax1*0.05];
    end    
end
for i=1:n_nd1
    cons=cons+[Tsmin<=Ts1(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr1(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s1(i,:)'==As1*Ts1(i,:)'];
    cons=cons+[Tout_r1(i,:)'==Ar1*Tr1(i,:)'];
    for j=1:n_nd1%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s1(j,:))~=0
            cons=cons+[Mout_s1(j,:)*Ts1(i,:)'==Min_s1(j,:)*Tout_s1(i,:)'];
        end
    end
    for j=1:n_nd1%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r1(j,:))~=0
            cons=cons+[Mout_r1(j,:)*Tr1(i,:)'==Min_r1(j,:)*Tin_r1(i,:)'];
        end
    end
    for j=1:length(n_ld1)
        cons=cons+[Tload(i)==4.182*10^-3*d1(n_ld1(j))*(Ts1(i,n_ld1(j))-Tr1(i,n_ld1(j)))];
    end
    for j=1:n_br1
        if i<=gama1(j) 
            cons=cons+[Tout_s1(i,j)==miu11(j)*Tsint+miu21(j)*Tsint];
            cons=cons+[Tin_r1(i,j)==miu11(j)*Trint+miu21(j)*Trint];
        elseif i>gama1(j) && i<=phi1(j)
            cons=cons+[Tout_s1(i,j)==miu11(j)*Tsint+miu21(j)*Tin_s1(i-gama1(j),j)];
            cons=cons+[Tin_r1(i,j)==miu11(j)*Trint+miu21(j)*Tout_r1(i-gama1(j),j)];  
        else
            cons=cons+[Tout_s1(i,j)==miu11(j)*Tin_s1(i-phi1(j),j)+miu21(j)*Tin_s1(i-gama1(j),j)];
            cons=cons+[Tin_r1(i,j)==miu11(j)*Tout_r1(i-phi1(j),j)+miu21(j)*Tout_r1(i-gama1(j),j)];  
        end
    end
end

%DHN2
Qchp2=sdpvar(len,1);%chp�ȹ���
Tin_s2=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_s2=sdpvar(len,n_br2);
Tin_r2=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_r2=sdpvar(len,n_br2);
Ts2=sdpvar(len,n_nd2);
Tr2=sdpvar(len,n_nd2);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp2(j)^2+20*Qchp2(j);
    cons=cons+[Qchp2(j)==-d2(1)*4.182*10^-3*(Ts2(j,1)-Tr2(j,1))];
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp2(j)-Qchp2(j-1)<=Qmax2*0.05];
    end    
end
for i=1:n_nd2
    cons=cons+[Tsmin<=Ts2(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr2(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s2(i,:)'==As2*Ts2(i,:)'];
    cons=cons+[Tout_r2(i,:)'==Ar2*Tr2(i,:)'];
    for j=1:n_nd2%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s2(j,:))~=0
            cons=cons+[Mout_s2(j,:)*Ts2(i,:)'==Min_s2(j,:)*Tout_s2(i,:)'];
        end
    end
    for j=1:n_nd2%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r2(j,:))~=0
            cons=cons+[Mout_r2(j,:)*Tr2(i,:)'==Min_r2(j,:)*Tin_r2(i,:)'];
        end
    end
    for j=1:length(n_ld2)
        cons=cons+[Tload(i)==4.182*10^-3*d2(n_ld2(j))*(Ts2(i,n_ld2(j))-Tr2(i,n_ld2(j)))];
    end
    for j=1:n_br2
        if i<=gama2(j) 
            cons=cons+[Tout_s2(i,j)==miu12(j)*Tsint+miu22(j)*Tsint];
            cons=cons+[Tin_r2(i,j)==miu12(j)*Trint+miu22(j)*Trint];
        elseif i>gama2(j) && i<=phi2(j)
            cons=cons+[Tout_s2(i,j)==miu12(j)*Tsint+miu22(j)*Tin_s2(i-gama2(j),j)];
            cons=cons+[Tin_r2(i,j)==miu12(j)*Trint+miu22(j)*Tout_r2(i-gama2(j),j)];  
        else
            cons=cons+[Tout_s2(i,j)==miu12(j)*Tin_s2(i-phi2(j),j)+miu22(j)*Tin_s2(i-gama2(j),j)];
            cons=cons+[Tin_r2(i,j)==miu12(j)*Tout_r2(i-phi2(j),j)+miu22(j)*Tout_r2(i-gama2(j),j)];  
        end
    end
end

%DHN3
Qchp3=sdpvar(len,1);%chp�ȹ���
Tin_s3=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_s3=sdpvar(len,n_br1);
Tin_r3=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_r3=sdpvar(len,n_br1);
Ts3=sdpvar(len,n_nd1);
Tr3=sdpvar(len,n_nd1);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp3(j)^2+20*Qchp3(j);
    cons=cons+[Qchp3(j)==-d1(1)*4.182*10^-3*(Ts3(j,1)-Tr3(j,1))];
    if j>=3
        cons=cons+[-Qmax1*0.05<=Qchp3(j)-Qchp3(j-1)<=Qmax1*0.05];
    end    
end
for i=1:n_nd1
    cons=cons+[Tsmin<=Ts3(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr3(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s3(i,:)'==As1*Ts3(i,:)'];
    cons=cons+[Tout_r3(i,:)'==Ar1*Tr3(i,:)'];
    for j=1:n_nd1%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s1(j,:))~=0
            cons=cons+[Mout_s1(j,:)*Ts3(i,:)'==Min_s1(j,:)*Tout_s3(i,:)'];
        end
    end
    for j=1:n_nd1%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r1(j,:))~=0
            cons=cons+[Mout_r1(j,:)*Tr3(i,:)'==Min_r1(j,:)*Tin_r3(i,:)'];
        end
    end
    for j=1:length(n_ld1)
        cons=cons+[Tload(i)==4.182*10^-3*d1(n_ld1(j))*(Ts3(i,n_ld1(j))-Tr3(i,n_ld1(j)))];
    end
    for j=1:n_br1
        if i<=gama1(j) 
            cons=cons+[Tout_s3(i,j)==miu11(j)*Tsint+miu21(j)*Tsint];
            cons=cons+[Tin_r3(i,j)==miu11(j)*Trint+miu21(j)*Trint];
        elseif i>gama1(j) && i<=phi1(j)
            cons=cons+[Tout_s3(i,j)==miu11(j)*Tsint+miu21(j)*Tin_s3(i-gama1(j),j)];
            cons=cons+[Tin_r3(i,j)==miu11(j)*Trint+miu21(j)*Tout_r3(i-gama1(j),j)];  
        else
            cons=cons+[Tout_s3(i,j)==miu11(j)*Tin_s3(i-phi1(j),j)+miu21(j)*Tin_s3(i-gama1(j),j)];
            cons=cons+[Tin_r3(i,j)==miu11(j)*Tout_r3(i-phi1(j),j)+miu21(j)*Tout_r3(i-gama1(j),j)];  
        end
    end
end

%DHN4
Qchp4=sdpvar(len,1);%chp�ȹ���
Tin_s4=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_s4=sdpvar(len,n_br2);
Tin_r4=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_r4=sdpvar(len,n_br2);
Ts4=sdpvar(len,n_nd2);
Tr4=sdpvar(len,n_nd2);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp4(j)^2+20*Qchp4(j);
    cons=cons+[Qchp4(j)==-d2(1)*4.182*10^-3*(Ts4(j,1)-Tr4(j,1))];
    if j>=2
        cons=cons+[-Qmax2*0.05<=Qchp4(j)-Qchp4(j-1)<=Qmax2*0.05];
    end    
end
for i=1:n_nd2
    cons=cons+[Tsmin<=Ts4(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr4(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s4(i,:)'==As2*Ts4(i,:)'];
    cons=cons+[Tout_r4(i,:)'==Ar2*Tr4(i,:)'];
    for j=1:n_nd2%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s2(j,:))~=0
            cons=cons+[Mout_s2(j,:)*Ts4(i,:)'==Min_s2(j,:)*Tout_s4(i,:)'];
        end
    end
    for j=1:n_nd2%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r2(j,:))~=0
            cons=cons+[Mout_r2(j,:)*Tr4(i,:)'==Min_r2(j,:)*Tin_r4(i,:)'];
        end
    end
    for j=1:length(n_ld2)
        cons=cons+[Tload(i)==4.182*10^-3*d2(n_ld2(j))*(Ts4(i,n_ld2(j))-Tr4(i,n_ld2(j)))];
    end
    for j=1:n_br2
        if i<=gama2(j) 
            cons=cons+[Tout_s4(i,j)==miu12(j)*Tsint+miu22(j)*Tsint];
            cons=cons+[Tin_r4(i,j)==miu12(j)*Trint+miu22(j)*Trint];
        elseif i>gama2(j) && i<=phi2(j)
            cons=cons+[Tout_s4(i,j)==miu12(j)*Tsint+miu22(j)*Tin_s4(i-gama2(j),j)];
            cons=cons+[Tin_r4(i,j)==miu12(j)*Trint+miu22(j)*Tout_r4(i-gama2(j),j)];  
        else
            cons=cons+[Tout_s4(i,j)==miu12(j)*Tin_s4(i-phi2(j),j)+miu22(j)*Tin_s4(i-gama2(j),j)];
            cons=cons+[Tin_r4(i,j)==miu12(j)*Tout_r4(i-phi2(j),j)+miu22(j)*Tout_r4(i-gama2(j),j)];  
        end
    end
end

%DHN5
Qchp5=sdpvar(len,1);%chp�ȹ���
Tin_s5=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_s5=sdpvar(len,n_br2);
Tin_r5=sdpvar(len,n_br2);%��ˮ���ܵ��¶�
Tout_r5=sdpvar(len,n_br2);
Ts5=sdpvar(len,n_nd2);
Tr5=sdpvar(len,n_nd2);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp5(j)^2+20*Qchp5(j);
    cons=cons+[Qchp5(j)==-d2(1)*4.182*10^-3*(Ts5(j,1)-Tr5(j,1))];
    if j>=2
        cons=cons+[-300*0.05<=Qchp5(j)-Qchp5(j-1)<=300*0.05];
    end    
end
for i=1:n_nd2
    cons=cons+[Tsmin<=Ts5(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr5(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s5(i,:)'==As2*Ts5(i,:)'];
    cons=cons+[Tout_r5(i,:)'==Ar2*Tr5(i,:)'];
    for j=1:n_nd2%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s2(j,:))~=0
            cons=cons+[Mout_s2(j,:)*Ts5(i,:)'==Min_s2(j,:)*Tout_s5(i,:)'];
        end
    end
    for j=1:n_nd2%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r2(j,:))~=0
            cons=cons+[Mout_r2(j,:)*Tr5(i,:)'==Min_r2(j,:)*Tin_r5(i,:)'];
        end
    end
    for j=1:length(n_ld2)
        cons=cons+[Tload(i)==4.182*10^-3*d2(n_ld2(j))*(Ts5(i,n_ld2(j))-Tr5(i,n_ld2(j)))];
    end
    for j=1:n_br2
        if i<=gama2(j) 
            cons=cons+[Tout_s5(i,j)==miu12(j)*Tsint+miu22(j)*Tsint];
            cons=cons+[Tin_r5(i,j)==miu12(j)*Trint+miu22(j)*Trint];
        elseif i>gama2(j) && i<=phi2(j)
            cons=cons+[Tout_s5(i,j)==miu12(j)*Tsint+miu22(j)*Tin_s5(i-gama2(j),j)];
            cons=cons+[Tin_r5(i,j)==miu12(j)*Trint+miu22(j)*Tout_r5(i-gama2(j),j)];  
        else
            cons=cons+[Tout_s5(i,j)==miu12(j)*Tin_s5(i-phi2(j),j)+miu22(j)*Tin_s5(i-gama2(j),j)];
            cons=cons+[Tin_r5(i,j)==miu12(j)*Tout_r5(i-phi2(j),j)+miu22(j)*Tout_r5(i-gama2(j),j)];  
        end
    end
end

%DHN6
Qchp6=sdpvar(len,1);%chp�ȹ���
Tin_s6=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_s6=sdpvar(len,n_br1);
Tin_r6=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_r6=sdpvar(len,n_br1);
Ts6=sdpvar(len,n_nd1);
Tr6=sdpvar(len,n_nd1);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp6(j)^2+20*Qchp6(j);
    cons=cons+[Qchp6(j)==-d1(1)*4.182*10^-3*(Ts6(j,1)-Tr6(j,1))];
    if j>=2
        cons=cons+[-Qmax1*0.05<=Qchp6(j)-Qchp6(j-1)<=Qmax1*0.05];
    end    
end
for i=1:n_nd1
    cons=cons+[Tsmin<=Ts6(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr6(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s6(i,:)'==As1*Ts6(i,:)'];
    cons=cons+[Tout_r6(i,:)'==Ar1*Tr6(i,:)'];
    for j=1:n_nd1%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s1(j,:))~=0
            cons=cons+[Mout_s1(j,:)*Ts6(i,:)'==Min_s1(j,:)*Tout_s6(i,:)'];
        end
    end
    for j=1:n_nd1%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r1(j,:))~=0
            cons=cons+[Mout_r1(j,:)*Tr6(i,:)'==Min_r1(j,:)*Tin_r6(i,:)'];
        end
    end
    for j=1:length(n_ld1)
        cons=cons+[Tload(i)==4.182*10^-3*d1(n_ld1(j))*(Ts6(i,n_ld1(j))-Tr6(i,n_ld1(j)))];
    end
    for j=1:n_br1
        if i<=gama1(j) 
            cons=cons+[Tout_s6(i,j)==miu11(j)*Tsint+miu21(j)*Tsint];
            cons=cons+[Tin_r6(i,j)==miu11(j)*Trint+miu21(j)*Trint];
        elseif i>gama1(j) && i<=phi1(j)
            cons=cons+[Tout_s6(i,j)==miu11(j)*Tsint+miu21(j)*Tin_s6(i-gama1(j),j)];
            cons=cons+[Tin_r6(i,j)==miu11(j)*Trint+miu21(j)*Tout_r6(i-gama1(j),j)];  
        else
            cons=cons+[Tout_s6(i,j)==miu11(j)*Tin_s6(i-phi1(j),j)+miu21(j)*Tin_s6(i-gama1(j),j)];
            cons=cons+[Tin_r6(i,j)==miu11(j)*Tout_r6(i-phi1(j),j)+miu21(j)*Tout_r6(i-gama1(j),j)];  
        end
    end
end

%DHN7
Qchp7=sdpvar(len,1);%chp�ȹ���
Tin_s7=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_s7=sdpvar(len,n_br1);
Tin_r7=sdpvar(len,n_br1);%��ˮ���ܵ��¶�
Tout_r7=sdpvar(len,n_br1);
Ts7=sdpvar(len,n_nd1);
Tr7=sdpvar(len,n_nd1);%�ڵ��¶�
for j=1:len%�豸Լ��
    sumcost=sumcost+0.04*Qchp7(j)^2+20*Qchp7(j);
    cons=cons+[Qchp7(j)==-d1(1)*4.182*10^-3*(Ts7(j,1)-Tr7(j,1))];
    if j>=2
        cons=cons+[-100*0.05<=Qchp7(j)-Qchp7(j-1)<=100*0.05];
    end    
end
for i=1:n_nd1
    cons=cons+[Tsmin<=Ts7(:,i)<=Tsmax];
    cons=cons+[Trmin<=Tr7(:,i)<=Trmax];
end    
for i=1:len
    %�������
    cons=cons+[Tin_s7(i,:)'==As1*Ts7(i,:)'];
    cons=cons+[Tout_r7(i,:)'==Ar1*Tr7(i,:)'];
    for j=1:n_nd1%���ڷ�Դ�ڵ��ڹ�ˮ�����¶Ȼ��
        if sum(Mout_s1(j,:))~=0
            cons=cons+[Mout_s1(j,:)*Ts7(i,:)'==Min_s1(j,:)*Tout_s7(i,:)'];
        end
    end
    for j=1:n_nd1%�Ǹ��ɽڵ��ڻ�ˮ�����¶Ȼ��
        if sum(Mout_r1(j,:))~=0
            cons=cons+[Mout_r1(j,:)*Tr7(i,:)'==Min_r1(j,:)*Tin_r7(i,:)'];
        end
    end
    for j=1:length(n_ld1)
        cons=cons+[Tload(i)==4.182*10^-3*d1(n_ld1(j))*(Ts7(i,n_ld1(j))-Tr7(i,n_ld1(j)))];
    end
    for j=1:n_br1
        if i<=gama1(j) 
            cons=cons+[Tout_s7(i,j)==miu11(j)*Tsint+miu21(j)*Tsint];
            cons=cons+[Tin_r7(i,j)==miu11(j)*Trint+miu21(j)*Trint];
        elseif i>gama1(j) && i<=phi1(j)
            cons=cons+[Tout_s7(i,j)==miu11(j)*Tsint+miu21(j)*Tin_s7(i-gama1(j),j)];
            cons=cons+[Tin_r7(i,j)==miu11(j)*Trint+miu21(j)*Tout_r7(i-gama1(j),j)];  
        else
            cons=cons+[Tout_s7(i,j)==miu11(j)*Tin_s7(i-phi1(j),j)+miu21(j)*Tin_s7(i-gama1(j),j)];
            cons=cons+[Tin_r7(i,j)==miu11(j)*Tout_r7(i-phi1(j),j)+miu21(j)*Tout_r7(i-gama1(j),j)];  
        end
    end
end

%% ���Լ��
cons=cons+[zeros(len,1)<=Qchp1<=ones(len,1)*Qmax1];%dhn1
cons=cons+[zeros(len,1)<=Pg(54,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(54,:)'<=Qmax1-0.1*Qchp1];
   
cons=cons+[zeros(len,1)<=Qchp2<=ones(len,1)*Qmax2];%dhn2
cons=cons+[zeros(len,1)<=Pg(61,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp2<=Pg(61,:)'<=Qmax2-0.1*Qchp2];

cons=cons+[zeros(len,1)<=Qchp3<=ones(len,1)*Qmax1];%dhn3
cons=cons+[zeros(len,1)<=Pg(103,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp1<=Pg(103,:)'<=Qmax1-0.1*Qchp3];

cons=cons+[zeros(len,1)<=Qchp4<=ones(len,1)*Qmax2];%dhn4
cons=cons+[zeros(len,1)<=Pg(49,:)'<=ones(len,1)*Qmax2];
cons=cons+[0.8*Qchp4<=Pg(49,:)'<=Qmax2-0.1*Qchp4];

cons=cons+[zeros(len,1)<=Qchp5<=ones(len,1)*300];%dhn5
cons=cons+[zeros(len,1)<=Pg(25,:)'<=ones(len,1)*300];
cons=cons+[0.8*Qchp5<=Pg(25,:)'<=300-0.1*Qchp5];
% 
cons=cons+[zeros(len,1)<=Qchp6<=ones(len,1)*Qmax1];%dhn6
cons=cons+[zeros(len,1)<=Pg(111,:)'<=ones(len,1)*Qmax1];
cons=cons+[0.8*Qchp6<=Pg(111,:)'<=Qmax1-0.1*Qchp6];

cons=cons+[zeros(len,1)<=Qchp7<=ones(len,1)*100];%dhn7
cons=cons+[zeros(len,1)<=Pg(12,:)'<=ones(len,1)*100];
cons=cons+[0.8*Qchp7<=Pg(12,:)'<=100-0.1*Qchp7];
%% ��ⲿ��
for k=1:len
    for j=1:N_gen
        sumcost=sumcost+Pg(mpc.gen(j,1),k)^2*mpc.gencost(j,5)...
            +Pg(mpc.gen(j,1),k)*mpc.gencost(j,6);
    end
end

opt=sdpsettings('solver', 'ipopt', 'verbose', 2);
tic
diag = optimize(cons,sumcost,opt);
toc
if diag.problem == 0
    fprintf('%s%f\n','sumcost = ', value(sumcost));
    Vm=value(Vm)';Va=value(Va)';
    Pl=value(Pl)';Ql=value(Ql)';
    Pg=value(Pg)';Qg=value(Qg)';

    Ts1=value(Ts1);Tr1=value(Tr1);
    Ts2=value(Ts2);Tr2=value(Tr2);
    Ts3=value(Ts3);Tr3=value(Tr3);
    Ts4=value(Ts4);Tr4=value(Tr4);
    Ts5=value(Ts5);Tr5=value(Tr5);
    Ts6=value(Ts6);Tr6=value(Tr6);
    Ts7=value(Ts7);Tr7=value(Tr7);

    Qchp1=value(Qchp1);
    Qchp2=value(Qchp2);
    Qchp3=value(Qchp3);
    Qchp4=value(Qchp4);
    Qchp5=value(Qchp5);
    Qchp6=value(Qchp6);
    Qchp7=value(Qchp7);
else
    yalmiperror(diag.problem)
end
